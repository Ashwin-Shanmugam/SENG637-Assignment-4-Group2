<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>AirCanada</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>a81eff7e-ce28-4422-92df-548b73136991</testSuiteGuid>
   <testCaseLink>
      <guid>3b12a0df-7025-487d-b8d3-f4830897a506</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AirCanada/TC-01</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>3bf2ddab-e4a8-4ac6-a092-ddfe4818530a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AirCanada/TC-02</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>4fac21aa-32cf-4923-a3cb-3336414fd158</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AirCanada/TC-03</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>07bdce4e-6218-4f5c-a1a9-934a128441c6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AirCanada/TC-04</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>952fb673-f586-4ce4-bb45-1cf13569a4be</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AirCanada/TC-06</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>46e014a3-e449-4a62-b318-b0e5ccde0342</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AirCanada/TC-07</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>dfa4f046-f78d-4e9e-ae43-b330df1cb87b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AirCanada/TC-08</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>927483e3-334a-43ba-95d8-53d5dd6f6c45</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AirCanada/TC-09</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>f1cf7a52-6907-4ff6-b174-658f456249cc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AirCanada/TC-05</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    