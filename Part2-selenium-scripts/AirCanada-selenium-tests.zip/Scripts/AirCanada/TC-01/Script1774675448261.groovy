import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://www.aircanada.com/home/ca/en/aco/flights")
selenium.click("xpath=//button[@id='bkmgFlights-trip-selector_tripTypeBtn']/abc-ripple/div")
selenium.click("xpath=//div[@id='bkmgFlights-trip-selector_tripTypeDialogPanelBody']/div[2]/fieldset/abc-radio-group/div/div/div[2]")
selenium.click("id=bkmgFlights-trip-selector_tripTypeSelector_O")
selenium.click("xpath=//div[@id='mainContent']/main/div/ac-flights/div/div/div/div/ac-bkmg-desktop/div/ac-one-trip-desktop/form/div/div/ac-dynamic-locations/div/ac-dynamic-locations-container")
selenium.click("xpath=//li[@id='flightsOriginLocationSearchResult0']/abc-ripple/div")
selenium.click("xpath=//div[@id='mainContent']/main/div/ac-flights/div/div/div/div/ac-bkmg-desktop/div/ac-one-trip-desktop/form/div/div/ac-dynamic-locations/div/ac-dynamic-locations-container[2]")
selenium.click("xpath=//li[@id='flightsOriginDestinationSearchResult1']/abc-ripple/div")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Billy Bishop Toronto City Airport'])[1]/following::*[name()='svg'][1]")
selenium.click("xpath=//div[@id='bkmg-desktop_travelDates-date-2026-04-10']/p")
selenium.click("xpath=//button[@id='bkmg-desktop_findButton']/span")
selenium.open("https://www.aircanada.com/booking/ca/en/aco/search?org0=YYC&dest0=YYZ&orgType0=A&destType0=A&departureDate0=10/04/2026&adt=1&yth=0&chd=0&inf=0&ins=0&marketCode=DOM&tripType=OneWay&isFlexible=false")
selenium.open("https://www.aircanada.com/booking/ca/en/aco/availability/ow/outbound")
